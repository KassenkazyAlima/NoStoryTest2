//
//  MovieTitle.swift
//  NoStoryTest
//
//  Created by astanahub on 06.05.2024.
//

import Foundation
import UIKit

struct MovieTitle{
    var titleLabel:String
    var image:UIImage?
}
